STEVE'S COLLECTION FOR MUM
==========================

TO INSTALL

1. Double-click:
   1 - INSTALL STEVES COLLECTION FOR MUM.cmd

2. If Windows asks whether you want to run it, confirm that you do.

3. That's it. The collection will open when installation is finished.

After that, Steve's Collection for Mum will open automatically when you sign in to Windows.
There will also be a shortcut called "Steve's Collection for Mum" on your Desktop.

Inside the collection you can:
- see a memory/photo
- browse all the pictures
- add your own information and memories
- add more photographs
- play "My Dear Old Mum"

HOME always takes you back to the main memory screen.
EXIT closes the collection.

Made for Mum by Steve.
