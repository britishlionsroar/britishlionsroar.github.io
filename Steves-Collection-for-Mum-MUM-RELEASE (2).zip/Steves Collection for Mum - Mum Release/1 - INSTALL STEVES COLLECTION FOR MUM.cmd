@echo off
setlocal
set "APPDIR=%LOCALAPPDATA%\StevesCollectionForMum"
set "HTML=%APPDIR%\Steves Collection for Mum.html"
title Steve's Collection for Mum - Setup

echo.
echo  ==============================================
echo          STEVE'S COLLECTION FOR MUM
echo  ==============================================
echo.
echo  Installing your collection...
echo.
if not exist "%APPDIR%" mkdir "%APPDIR%"
copy /Y "%~dp0Steves Collection for Mum.html" "%HTML%" >nul
if errorlevel 1 goto :fail

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
 "$edge=(Get-Command msedge.exe -ErrorAction SilentlyContinue).Source; if(-not $edge){$p1=Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'; $p2=Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe'; if(Test-Path $p1){$edge=$p1}elseif(Test-Path $p2){$edge=$p2}else{throw 'Microsoft Edge was not found.'}}; $url='file:///' + ('%HTML%'.Replace('\','/').Replace(' ','%%20')); $ws=New-Object -ComObject WScript.Shell; $desktop=[Environment]::GetFolderPath('Desktop'); $s=$ws.CreateShortcut((Join-Path $desktop 'Steve''s Collection for Mum.lnk')); $s.TargetPath=$edge; $s.Arguments='--app="'+$url+'"'; $s.WorkingDirectory='%APPDIR%'; $s.IconLocation=$edge+',0'; $s.Save(); $startup=[Environment]::GetFolderPath('Startup'); $a=$ws.CreateShortcut((Join-Path $startup 'Steve''s Collection for Mum.lnk')); $a.TargetPath=$edge; $a.Arguments='--app="'+$url+'"'; $a.WorkingDirectory='%APPDIR%'; $a.IconLocation=$edge+',0'; $a.Save(); Start-Process $edge -ArgumentList ('--app="'+$url+'"')"
if errorlevel 1 goto :fail

echo.
echo  ALL DONE!
echo.
echo  Steve's Collection for Mum is now installed.
echo  It will open automatically when Windows starts.
echo  There is also a shortcut on the Desktop.
echo.
timeout /t 6 >nul
exit /b 0

:fail
echo.
echo  Sorry - Windows could not finish the installation.
echo  Nothing important has been changed or deleted.
echo  Ask Steve for help.
echo.
pause
exit /b 1
