@echo off
setlocal
set "APPDIR=%LOCALAPPDATA%\StevesCollectionForMum"
echo.
echo This removes Steve's Collection for Mum from this PC.
echo.
choice /C YN /N /M "Remove it now? [Y/N] "
if errorlevel 2 exit /b 0
powershell -NoProfile -ExecutionPolicy Bypass -Command "$d=Join-Path ([Environment]::GetFolderPath('Desktop')) 'Steve''s Collection for Mum.lnk'; $s=Join-Path ([Environment]::GetFolderPath('Startup')) 'Steve''s Collection for Mum.lnk'; if(Test-Path $d){Remove-Item $d -Force}; if(Test-Path $s){Remove-Item $s -Force}"
if exist "%APPDIR%" rmdir /S /Q "%APPDIR%"
echo.
echo Removed.
echo.
pause
