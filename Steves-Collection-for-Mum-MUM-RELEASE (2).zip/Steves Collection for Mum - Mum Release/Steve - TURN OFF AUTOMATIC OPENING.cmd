@echo off
powershell -NoProfile -ExecutionPolicy Bypass -Command "$p=Join-Path ([Environment]::GetFolderPath('Startup')) 'Steve''s Collection for Mum.lnk'; if(Test-Path $p){Remove-Item $p -Force}"
echo.
echo Automatic opening has been turned off.
echo The collection and Desktop shortcut have NOT been removed.
echo.
pause
